"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Menu, X } from "lucide-react"

interface HeaderProps {
  activeTab: string
  onTabChange: (tab: string) => void
}

export default function Header({ activeTab, onTabChange }: HeaderProps) {
  const [isMenuOpen, setIsMenuOpen] = useState(false)
  const [isScrolled, setIsScrolled] = useState(false)

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50)
    }
    window.addEventListener("scroll", handleScroll)
    return () => window.removeEventListener("scroll", handleScroll)
  }, [])

  const menuItems = [
    { label: "Início", id: "home" },
    { label: "A Escolinha", id: "sobre" },
    { label: "Treinos", id: "treinos" },
    { label: "Campeonatos", id: "campeonatos" },
    { label: "Vídeos", id: "videos" },
    { label: "Galeria", id: "galeria" },
    { label: "Parcerias", id: "parcerias" },
    { label: "Depoimentos", id: "depoimentos" },
    { label: "Contato", id: "contato" },
  ]

  // Atualizar o botão "Inscreva-se" do header para usar o novo link
  const handleInscricaoClick = () => {
    const whatsappUrl =
      "https://linktr.ee/Escolinha10NaBola?fbclid=PAZXh0bgNhZW0CMTEAAacrO_kAG8u5AkYnVPtJTjENaE9qkoTbGwCTWheUKm7pmAqVCWtlxSsp4v15XA_aem_voYzNcNViPY9U41uxjvuVg"
    window.open(whatsappUrl, "_blank")
  }

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        isScrolled
          ? "bg-gradient-to-r from-black via-red-800 to-red-600 backdrop-blur-xl shadow-lg border-b border-red-600/50"
          : "bg-gradient-to-r from-black via-red-800 to-red-600 backdrop-blur-md"
      }`}
    >
      <div className="container mx-auto px-6">
        <div className="flex items-center justify-between h-20">
          {/* Logo - Aumentada */}
          <Link href="/" className="flex items-center group" onClick={() => onTabChange("home")}>
            <div className="relative">
              <Image
                src="/images/logo-10-na-bola-escudo.png"
                alt="10 na Bola"
                width={80}
                height={80}
                className="w-[80px] h-[80px] object-contain transition-transform duration-300 group-hover:scale-105"
              />
            </div>
          </Link>

          {/* Desktop Menu */}
          <nav className="hidden lg:flex items-center space-x-8">
            {menuItems.map((item, index) => (
              <button
                key={item.label}
                onClick={() => onTabChange(item.id)}
                className={`font-medium text-sm tracking-wide transition-colors duration-300 ${
                  activeTab === item.id ? "text-red-200" : "text-white hover:text-red-200"
                }`}
              >
                {item.label}
              </button>
            ))}
          </nav>

          {/* CTA Button */}
          <div className="hidden lg:block">
            {/* Substituir o onClick do botão "Inscreva-se" no header */}
            <Button
              className="bg-white text-red-600 hover:bg-red-50 font-medium px-6 py-2.5 text-sm tracking-wide transition-all duration-300 hover:shadow-lg"
              onClick={handleInscricaoClick}
            >
              Inscreva-se
            </Button>
          </div>

          {/* Mobile Menu Button */}
          <button
            className="lg:hidden p-2 rounded-lg hover:bg-red-800/50 transition-colors duration-300"
            onClick={() => setIsMenuOpen(!isMenuOpen)}
          >
            <div className="relative w-6 h-6">
              <Menu
                className={`absolute inset-0 transition-all duration-300 text-white ${isMenuOpen ? "opacity-0 rotate-90" : "opacity-100 rotate-0"}`}
                size={24}
              />
              <X
                className={`absolute inset-0 transition-all duration-300 ${isMenuOpen ? "opacity-100 rotate-0" : "opacity-0 -rotate-90"}`}
                size={24}
              />
            </div>
          </button>
        </div>

        {/* Mobile Menu */}
        <div
          className={`lg:hidden overflow-hidden transition-all duration-300 ${
            isMenuOpen ? "max-h-80 opacity-100 pb-6" : "max-h-0 opacity-0"
          }`}
        >
          <div className="border-t border-red-600 pt-6">
            <nav className="flex flex-col space-y-4">
              {menuItems.map((item, index) => (
                <button
                  key={item.label}
                  onClick={() => {
                    onTabChange(item.id)
                    setIsMenuOpen(false)
                  }}
                  className={`text-left font-medium text-sm tracking-wide transition-colors duration-300 ${
                    activeTab === item.id ? "text-red-200" : "text-white hover:text-red-200"
                  }`}
                >
                  {item.label}
                </button>
              ))}
              {/* E também no menu mobile */}
              <Button
                className="bg-white text-red-600 hover:bg-red-50 font-medium w-full mt-4"
                onClick={() => {
                  handleInscricaoClick()
                  setIsMenuOpen(false)
                }}
              >
                Inscreva-se
              </Button>
            </nav>
          </div>
        </div>
      </div>
    </header>
  )
}
