"use client"

import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import Image from "next/image"
import { Clock, Calendar, Users, Target, MapPin, Star } from "lucide-react"

interface TrainingTabProps {
  onTabChange: (tab: string) => void
}

export default function TrainingTab({ onTabChange }: TrainingTabProps) {
  // Atualizar todos os botões "Inscrever-se" e "Inscrever na [categoria]" para usar o novo link
  const handleInscricaoClick = () => {
    const whatsappUrl =
      "https://linktr.ee/Escolinha10NaBola?fbclid=PAZXh0bgNhZW0CMTEAAacrO_kAG8u5AkYnVPtJTjENaE9qkoTbGwCTWheUKm7pmAqVCWtlxSsp4v15XA_aem_voYzNcNViPY9U41uxjvuVg"
    window.open(whatsappUrl, "_blank")
  }

  const categories = [
    {
      name: "Sub-08",
      age: "6-8 anos",
      schedule: "Segunda-feira - 18h às 19h30",
      focus: "Iniciação e coordenação motora",
      students: "25+ alunos",
      description: "Primeira experiência com o futebol, focando em diversão, coordenação motora e socialização.",
      objectives: [
        "Desenvolvimento da coordenação motora",
        "Primeiros contatos com a bola",
        "Socialização e trabalho em grupo",
        "Disciplina básica e respeito às regras",
      ],
      image: "/images/treino-sub08-criancas.png",
      color: "blue",
      highlight: false,
    },
    {
      name: "Sub-10",
      age: "8-10 anos",
      schedule: "Seg/Qua/Sex - 16h às 17h30",
      focus: "Fundamentos básicos",
      students: "30+ alunos",
      description: "Aprendizado dos fundamentos básicos do futebol com exercícios lúdicos e educativos.",
      objectives: [
        "Fundamentos técnicos básicos",
        "Noções táticas simples",
        "Desenvolvimento físico adequado",
        "Formação de caráter e valores",
      ],
      image: "/images/copa-real-kids-2024-sub10-treino.png",
      color: "green",
      highlight: false,
    },
    {
      name: "Sub-12",
      age: "10-12 anos",
      schedule: "Seg/Qua/Sex - 17h30 às 19h",
      focus: "Técnica e tática básica",
      students: "35+ alunos",
      description: "Aprimoramento técnico e introdução aos conceitos táticos fundamentais do futebol.",
      objectives: [
        "Refinamento técnico individual",
        "Conceitos táticos básicos",
        "Preparação física específica",
        "Liderança e responsabilidade",
      ],
      image: "/images/participacao-copa-ad-soccer-sub12.png",
      color: "red",
      highlight: true,
    },
    {
      name: "Sub-14",
      age: "12-14 anos",
      schedule: "Ter/Qui/Sáb - 18h às 19h30",
      focus: "Desenvolvimento técnico-tático",
      students: "28+ alunos",
      description: "Desenvolvimento avançado com foco em técnica refinada e entendimento tático do jogo.",
      objectives: [
        "Técnica individual avançada",
        "Sistemas táticos complexos",
        "Preparação física intensiva",
        "Mentalidade competitiva",
      ],
      image: "/images/treino-orientacoes.png",
      color: "purple",
      highlight: true,
    },
    {
      name: "Sub-16",
      age: "14-16 anos",
      schedule: "Ter/Qui/Sáb - 19h30 às 21h",
      focus: "Alto rendimento e preparação",
      students: "22+ alunos",
      description: "Preparação para o alto rendimento com treinos específicos e orientação profissional.",
      objectives: [
        "Alto rendimento técnico",
        "Preparação para competições",
        "Orientação profissional",
        "Desenvolvimento de liderança",
      ],
      image: "/images/treino-sub17-descanso.png",
      color: "orange",
      highlight: true,
    },
  ]

  const getColorClasses = (color: string) => {
    const colors = {
      blue: {
        bg: "bg-blue-50",
        border: "border-blue-200",
        text: "text-blue-600",
        button: "bg-blue-600 hover:bg-blue-700",
      },
      green: {
        bg: "bg-green-50",
        border: "border-green-200",
        text: "text-green-600",
        button: "bg-green-600 hover:bg-green-700",
      },
      red: {
        bg: "bg-red-50",
        border: "border-red-200",
        text: "text-red-600",
        button: "bg-red-600 hover:bg-red-700",
      },
      purple: {
        bg: "bg-purple-50",
        border: "border-purple-200",
        text: "text-purple-600",
        button: "bg-purple-600 hover:bg-purple-700",
      },
      orange: {
        bg: "bg-orange-50",
        border: "border-orange-200",
        text: "text-orange-600",
        button: "bg-orange-600 hover:bg-orange-700",
      },
    }
    return colors[color as keyof typeof colors] || colors.blue
  }

  return (
    <div className="space-y-16 py-8">
      {/* Header */}
      <section className="text-center">
        <div className="inline-flex items-center px-4 py-2 bg-green-100 rounded-full mb-6">
          <span className="text-green-700 text-sm font-medium tracking-wide">Nossas Turmas</span>
        </div>
        <h1 className="text-4xl md:text-5xl font-bold text-slate-900 mb-6">Treinos e Categorias</h1>
        <p className="text-xl text-slate-600 max-w-3xl mx-auto leading-relaxed">
          Conheça nossas categorias organizadas por idade e nível de desenvolvimento
        </p>
      </section>

      {/* Categorias Detalhadas */}
      <section className="container mx-auto px-6">
        <div className="space-y-16">
          {categories.map((category, index) => {
            const colorClasses = getColorClasses(category.color)
            return (
              <div
                key={category.name}
                className={`${index % 2 === 1 ? "lg:flex-row-reverse" : ""} flex flex-col lg:flex-row gap-12 items-center`}
              >
                <div className="lg:w-1/2 space-y-6">
                  <div className="flex items-center space-x-4">
                    <h2 className={`text-4xl font-bold ${colorClasses.text}`}>{category.name}</h2>
                    {category.highlight && (
                      <div className="bg-red-600 text-white text-xs font-medium px-3 py-1 rounded-full flex items-center space-x-1">
                        <Star className="w-3 h-3 fill-current" />
                        <span>Destaque</span>
                      </div>
                    )}
                  </div>

                  <p className="text-lg text-slate-600 leading-relaxed">{category.description}</p>

                  {/* Informações da Categoria */}
                  <div className="grid md:grid-cols-2 gap-4">
                    <Card className={`${colorClasses.bg} ${colorClasses.border} border-2`}>
                      <CardContent className="p-4">
                        <div className="flex items-center space-x-3">
                          <Calendar className={`w-5 h-5 ${colorClasses.text}`} />
                          <div>
                            <div className="text-sm font-medium text-slate-600">Idade</div>
                            <div className="font-bold text-slate-900">{category.age}</div>
                          </div>
                        </div>
                      </CardContent>
                    </Card>

                    <Card className={`${colorClasses.bg} ${colorClasses.border} border-2`}>
                      <CardContent className="p-4">
                        <div className="flex items-center space-x-3">
                          <Clock className={`w-5 h-5 ${colorClasses.text}`} />
                          <div>
                            <div className="text-sm font-medium text-slate-600">Horário</div>
                            <div className="font-bold text-slate-900 text-sm">{category.schedule}</div>
                          </div>
                        </div>
                      </CardContent>
                    </Card>

                    <Card className={`${colorClasses.bg} ${colorClasses.border} border-2`}>
                      <CardContent className="p-4">
                        <div className="flex items-center space-x-3">
                          <Users className={`w-5 h-5 ${colorClasses.text}`} />
                          <div>
                            <div className="text-sm font-medium text-slate-600">Alunos</div>
                            <div className="font-bold text-slate-900">{category.students}</div>
                          </div>
                        </div>
                      </CardContent>
                    </Card>

                    <Card className={`${colorClasses.bg} ${colorClasses.border} border-2`}>
                      <CardContent className="p-4">
                        <div className="flex items-center space-x-3">
                          <Target className={`w-5 h-5 ${colorClasses.text}`} />
                          <div>
                            <div className="text-sm font-medium text-slate-600">Foco</div>
                            <div className="font-bold text-slate-900 text-sm">{category.focus}</div>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  </div>

                  {/* Objetivos */}
                  <div>
                    <h3 className="text-xl font-bold text-slate-900 mb-4">Objetivos da Categoria</h3>
                    <ul className="space-y-2">
                      {category.objectives.map((objective, idx) => (
                        <li key={idx} className="flex items-center space-x-3">
                          <div className={`w-2 h-2 ${colorClasses.text.replace("text-", "bg-")} rounded-full`}></div>
                          <span className="text-slate-600">{objective}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  {/* Substituir todos os botões de inscrição */}
                  <Button
                    className={`${colorClasses.button} text-white font-medium px-8 py-3`}
                    onClick={handleInscricaoClick}
                  >
                    Inscrever na {category.name}
                  </Button>
                </div>

                <div className="lg:w-1/2">
                  <div className="relative">
                    <Image
                      src={category.image || "/placeholder.svg"}
                      alt={`Treino ${category.name}`}
                      width={500}
                      height={400}
                      className="rounded-2xl w-full h-auto shadow-2xl"
                    />
                    <div
                      className={`absolute -bottom-4 -right-4 w-20 h-20 ${colorClasses.text.replace("text-", "bg-")} rounded-2xl opacity-20`}
                    ></div>
                  </div>
                </div>
              </div>
            )
          })}
        </div>
      </section>

      {/* Informações Gerais */}
      <section className="bg-slate-50 py-16">
        <div className="container mx-auto px-6">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-slate-900 mb-4">Informações Gerais dos Treinos</h2>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            <Card className="text-center hover:shadow-xl transition-all duration-300">
              <CardContent className="p-6">
                <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <MapPin className="w-8 h-8 text-blue-600" />
                </div>
                <h3 className="text-lg font-bold text-slate-900 mb-2">Local</h3>
                <p className="text-slate-600 text-sm">Rua José Vieira Martins, 270 - Jardim Itapura</p>
              </CardContent>
            </Card>

            <Card className="text-center hover:shadow-xl transition-all duration-300">
              <CardContent className="p-6">
                <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <span className="text-2xl">🆓</span>
                </div>
                <h3 className="text-lg font-bold text-slate-900 mb-2">Aula Experimental</h3>
                <p className="text-slate-600 text-sm">Primeira aula gratuita para conhecer</p>
              </CardContent>
            </Card>

            <Card className="text-center hover:shadow-xl transition-all duration-300">
              <CardContent className="p-6">
                <div className="w-16 h-16 bg-yellow-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <span className="text-2xl">💰</span>
                </div>
                <h3 className="text-lg font-bold text-slate-900 mb-2">Mensalidade</h3>
                <p className="text-slate-600 text-sm">Treinos com valor acessível</p>
              </CardContent>
            </Card>

            <Card className="text-center hover:shadow-xl transition-all duration-300">
              <CardContent className="p-6">
                <div className="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <span className="text-2xl">👕</span>
                </div>
                <h3 className="text-lg font-bold text-slate-900 mb-2">Uniforme</h3>
                <p className="text-slate-600 text-sm">Uniforme oficial vendido separadamente</p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="bg-gradient-to-r from-green-600 to-blue-900 py-16">
        <div className="container mx-auto px-6 text-center">
          <h2 className="text-3xl font-bold text-white mb-6">Pronto para Começar?</h2>
          <p className="text-xl text-green-100 mb-8 max-w-2xl mx-auto">
            Escolha a categoria ideal para seu filho e faça parte da nossa família
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            {/* E também os botões "Fazer Inscrição" */}
            <Button
              size="lg"
              className="bg-white text-green-600 hover:bg-slate-100 font-medium px-8 py-4"
              onClick={handleInscricaoClick}
            >
              Fazer Inscrição
            </Button>
            <Button
              size="lg"
              variant="outline"
              className="border-2 border-white text-white hover:bg-white hover:text-green-600 font-medium px-8 py-4 bg-transparent"
              onClick={() => onTabChange("sobre")}
            >
              Conhecer Escola
            </Button>
          </div>
        </div>
      </section>
    </div>
  )
}
