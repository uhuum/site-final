"use client"

import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Calendar, ArrowLeft, Share2, Heart } from "lucide-react"
import Image from "next/image"

interface SingleNewsTabProps {
  newsId: string
  onTabChange: (tab: string) => void
  onBackToNews: () => void
}

export default function SingleNewsTab({ newsId, onTabChange, onBackToNews }: SingleNewsTabProps) {
  // Atualizar os botões "Entre em Contato" para usar o novo link
  const handleContactClick = () => {
    const whatsappUrl =
      "https://linktr.ee/Escolinha10NaBola?fbclid=PAZXh0bgNhZW0CMTEAAacrO_kAG8u5AkYnVPtJTjENaE9qkoTbGwCTWheUKm7pmAqVCWtlxSsp4v15XA_aem_voYzNcNViPY9U41uxjvuVg"
    window.open(whatsappUrl, "_blank")
  }

  const allNews = [
    {
      id: "copa-rei-2025",
      title: "Conquista Histórica na Copa do Rei 2025",
      date: "28 de Junho, 2025",
      excerpt:
        "Nossas equipes Sub-13 e Sub-17 conquistaram o título da Copa do Rei 2025, marcando um ano histórico para nossa escola.",
      image: "/images/copa-rei-2025-sub13-campeao.png",
      category: "Campeonatos",
      highlight: true,
      content: `
        <p>Em uma campanha histórica, as equipes Sub-13 e Sub-17 da Escola de Futebol 10 na Bola conquistaram os títulos da Copa do Rei 2025, consolidando nossa posição como uma das principais escolas de futebol da Zona Sul de São Paulo.</p>
        
        <h3>Sub-13 - Campeões Invictos</h3>
        <p>A equipe Sub-13 teve uma campanha perfeita, vencendo todos os jogos da competição. Com um futebol técnico e muita garra, os meninos mostraram que o trabalho de base da nossa escola está dando frutos.</p>
        
        <h3>Sub-17 - Dominando a Categoria</h3>
        <p>Já a equipe Sub-17 confirmou o favoritismo e conquistou o título com autoridade. Os jogadores demonstraram maturidade tática e técnica exemplares durante toda a competição.</p>
        
        <p>Essas conquistas são resultado do trabalho dedicado de nossos treinadores e do comprometimento de nossos atletas, que treinam com disciplina e paixão pelo esporte.</p>
      `,
    },
    {
      id: "copa-art-soccer-2025",
      title: "Finais da Copa Art Soccer 2025",
      date: "29 de Junho, 2025",
      excerpt:
        "As equipes Sub-08, Sub-10, Sub-12 e Sub-14 da Escolinha 10 na Bola participaram das emocionantes finais da Copa Art Soccer 2025.",
      image: "/images/copa-art-soccer-2025-finais.png",
      category: "Campeonatos",
      highlight: true,
      content: `
        <p>A Copa Art Soccer 2025 foi palco de grandes emoções para nossas categorias de base. Quatro equipes da Escolinha 10 na Bola chegaram às finais, demonstrando a qualidade do trabalho desenvolvido em todas as idades.</p>
        
        <h3>Resultados das Finais</h3>
        <ul>
          <li><strong>Sub-08:</strong> Vice-campeão - Uma campanha excepcional para os mais novos</li>
          <li><strong>Sub-10:</strong> Campeão - Título conquistado com futebol bonito</li>
          <li><strong>Sub-12:</strong> Vice-campeão - Chegaram à final com muita determinação</li>
          <li><strong>Sub-14:</strong> Campeão - Dominaram a categoria do início ao fim</li>
        </ul>
        
        <p>Independente dos resultados, todos os nossos atletas estão de parabéns pela dedicação e espírito esportivo demonstrados durante toda a competição.</p>
      `,
    },
    {
      id: "ferias-2025",
      title: "Férias com Bola Rolando!",
      date: "01 de Julho, 2025",
      excerpt: "Dia 01 de julho marcou o início oficial das férias na Escolinha 10 na Bola com atividades especiais.",
      image: "/images/DIA 01-07 INICIO DAS FÉRIAS NA NOSSA ESCOLINHA (1).png",
      category: "Comunicados",
      highlight: true,
      content: `
        <p>As férias escolares chegaram, mas na Escolinha 10 na Bola a diversão e o aprendizado continuam! Nosso Treinamento Especial de Férias oferece uma programação diferenciada para manter nossos atletas ativos e engajados.</p>
        
        <h3>Programação Especial</h3>
        <ul>
          <li>Treinos técnicos com atividades lúdicas</li>
          <li>Jogos recreativos entre as categorias</li>
          <li>Atividades de integração e confraternização</li>
          <li>Workshops sobre nutrição esportiva</li>
          <li>Sessões de cinema com filmes esportivos</li>
        </ul>
        
        <h3>Horários das Férias</h3>
        <p>Durante o período de férias, mantemos nossos horários normais de funcionamento: Segunda a Sexta, das 18h às 20h30.</p>
        
        <p>Venha participar e aproveitar as férias com muita bola no pé!</p>
      `,
    },
    {
      id: "camisas-venda-2025",
      title: "Camisas à Venda – 10 na Bola",
      date: "01 de Julho, 2025",
      excerpt:
        "Já estão disponíveis as novas camisas oficiais da Escolinha 10 na Bola! Garanta a sua e venha treinar com o manto.",
      image: "/images/COPA SOCCER EDIÇÃO 2024 (2).png",
      category: "Comunicados",
      highlight: true,
      content: `
        <p>Chegaram as novas camisas oficiais da Escolinha 10 na Bola! Com design moderno e material de alta qualidade, nossos uniformes estão disponíveis para toda a família.</p>
        
        <h3>Modelos Disponíveis</h3>
        <ul>
          <li><strong>Camisa Oficial Cinza:</strong> Modelo principal para treinos e jogos</li>
          <li><strong>Camisa Oficial Branca:</strong> Modelo alternativo para competições</li>
        </ul>
        
        <h3>Tamanhos e Preços</h3>
        <ul>
          <li>Infantil (2 a 12 anos): R$ 45,00</li>
          <li>Juvenil (14 a 16 anos): R$ 50,00</li>
          <li>Adulto (P ao GG): R$ 55,00</li>
        </ul>
        
        <h3>Como Adquirir</h3>
        <p>Entre em contato conosco pelo WhatsApp ou venha até a escola durante nossos horários de funcionamento. Aceitamos dinheiro, PIX e cartão.</p>
        
        <p>Vista a camisa da 10 na Bola e mostre seu orgulho de fazer parte da nossa família!</p>
      `,
    },
  ]

  const news = allNews.find((n) => n.id === newsId)

  if (!news) {
    return (
      <div className="container mx-auto px-6 py-24 text-center">
        <h1 className="text-3xl font-bold text-slate-900 mb-4">Notícia não encontrada</h1>
        <p className="text-xl text-slate-600 mb-8">A notícia que você está procurando não existe.</p>
        <Button onClick={() => onTabChange("home")} className="bg-blue-900 hover:bg-blue-800 text-white">
          Voltar ao Início
        </Button>
      </div>
    )
  }

  return (
    <div className="space-y-8 py-8">
      <section className="container mx-auto px-6">
        <div className="flex items-center space-x-4 mb-8">
          <Button
            variant="outline"
            onClick={onBackToNews}
            className="flex items-center space-x-2 border-2 border-slate-300 text-slate-700 hover:bg-slate-50 bg-transparent"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>Voltar às Notícias</span>
          </Button>
          <div className="text-slate-400">|</div>
          <span className="text-slate-600">{news.category}</span>
        </div>
      </section>

      <section className="container mx-auto px-6">
        <Card className="overflow-hidden shadow-2xl">
          <div className="relative h-96 md:h-[500px]">
            <Image src={news.image || "/placeholder.svg"} alt={news.title} fill className="object-cover" />
            <div className="absolute inset-0 bg-gradient-to-t from-slate-900/80 via-slate-900/20 to-transparent"></div>

            {news.highlight && (
              <div className="absolute top-6 left-6">
                <span className="bg-red-600 text-white px-4 py-2 rounded-full text-sm font-bold shadow-lg">
                  🔥 DESTAQUE
                </span>
              </div>
            )}

            <div className="absolute top-6 right-6">
              <span className="bg-blue-900 text-white px-4 py-2 rounded-full text-sm font-semibold">
                {news.category}
              </span>
            </div>

            <div className="absolute bottom-8 left-8 right-8 text-white">
              <div className="flex items-center space-x-3 text-slate-200 text-sm mb-4">
                <Calendar className="w-5 h-5" />
                <span>{news.date}</span>
              </div>
              <h1 className="text-3xl md:text-5xl font-bold mb-4 leading-tight">{news.title}</h1>
              <p className="text-xl text-slate-200 leading-relaxed">{news.excerpt}</p>
            </div>
          </div>
        </Card>
      </section>

      <section className="container mx-auto px-6">
        <div className="max-w-4xl mx-auto">
          <Card className="bg-white shadow-lg">
            <CardContent className="p-12">
              <div className="flex items-center justify-between mb-8 pb-8 border-b border-slate-200">
                <div className="flex items-center space-x-4">
                  <Button variant="outline" size="sm" className="flex items-center space-x-2 bg-transparent">
                    <Heart className="w-4 h-4" />
                    <span>Curtir</span>
                  </Button>
                  <Button variant="outline" size="sm" className="flex items-center space-x-2 bg-transparent">
                    <Share2 className="w-4 h-4" />
                    <span>Compartilhar</span>
                  </Button>
                </div>
                <div className="text-sm text-slate-500">Publicado em {news.date}</div>
              </div>

              <div
                className="prose prose-lg max-w-none prose-headings:text-slate-900 prose-p:text-slate-700 prose-p:leading-relaxed prose-ul:text-slate-700 prose-li:text-slate-700"
                dangerouslySetInnerHTML={{ __html: news.content }}
              />

              <div className="mt-12 pt-8 border-t border-slate-200">
                <div className="bg-blue-50 rounded-2xl p-8 text-center">
                  <h3 className="text-2xl font-bold text-slate-900 mb-4">Gostou da notícia?</h3>
                  <p className="text-slate-600 mb-6">
                    Faça parte da nossa família e acompanhe de perto todas as conquistas e novidades!
                  </p>
                  <div className="flex flex-col sm:flex-row gap-4 justify-center">
                    {/* Substituir o botão "Entre em Contato" */}
                    <Button className="bg-blue-900 hover:bg-blue-800 text-white" onClick={handleContactClick}>
                      Entre em Contato
                    </Button>
                    <Button
                      variant="outline"
                      className="border-2 border-blue-900 text-blue-900 hover:bg-blue-50 bg-transparent"
                      onClick={() => onTabChange("sobre")}
                    >
                      Conheça a Escola
                    </Button>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </section>
    </div>
  )
}
